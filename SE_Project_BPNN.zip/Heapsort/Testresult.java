package Heapsort;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
public class Testresult {
	
	/*
	 * read the test case file by line, store it in a List
	 * use correct Heapsort.Sort to sort this List
	 * write the test result in the test oracle file
	 */
	
	public static File getTestoracle(File TCfile) {

		String path = "c:\\Users\\qhy\\Desktop\\Tarantula\\Heapsort\\Testoracle-"+TCfile.getName();
		List<Integer> Testcase=new ArrayList<Integer>();
		
		Heapsort h=new Heapsort();
		
		//create a new test oracle file
		File TOfile=null;
	
		try {
			
			TOfile = new File(path);        
			
			if(!TOfile.exists()){    
				TOfile.createNewFile();                 
				}  
			
	        // used to write  the test result to the  test oracle file    
			FileWriter fw = new FileWriter(TOfile, true);        
			BufferedWriter bw = new BufferedWriter(fw);  
			
			//read the data of the test case file by line 
			InputStream is = null;
	        Reader reader = null;
	        BufferedReader bufferedReader = null;
	        is = new FileInputStream(TCfile);
	        reader = new InputStreamReader(is);
	        bufferedReader = new BufferedReader(reader);
	        String line = null;
	        
	        while ((line = bufferedReader.readLine()) != null) {
	        	Testcase=String2List(line);
	            
	        	//get the test result
	            h.Sort(Testcase);
	            
	            //store in the test oracle file
	            for(int i=0;i<Testcase.size();i++) {
	            	bw.write(Testcase.get(i)+" ");
	            }
	                
	                bw.newLine();
	            }

	        	Heapsort.clearCoverage();
	            
	        	bw.flush();        
    			bw.close();        
    			fw.close();
    			 
	            bufferedReader.close();
	            reader.close();
	            is.close();
    			
	            
	            
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } 	
		return TOfile;

	}
	
	/*
	 * read the test case file by line, store it in a List
	 * use incorrect Heapsort.Sort to sort this List
	 * write the test result in the test result file
	 * the way of implement is same as the above method
	 */
	
	public static File getTestresult(File TCfile) {
		//String fileName =new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())+".txt";
		//System.out.println(fileName);
		
		String path = "c:\\Users\\qhy\\Desktop\\Tarantula\\Heapsort\\Testresult-"+TCfile.getName();
		List<Integer> Testcase=new ArrayList<Integer>();
		
		Heapsort h=new Heapsort();
		
		File TOfile=null;
	
		try {
			
			TOfile = new File(path);        
			
			if(!TOfile.exists()){    
				TOfile.createNewFile();                 
				}  
			
	        // write        
			FileWriter fw = new FileWriter(TOfile, true);        
			BufferedWriter bw = new BufferedWriter(fw);  
			
			//read
			InputStream is = null;
	        Reader reader = null;
	        BufferedReader bufferedReader = null;
	      
	        is = new FileInputStream(TCfile);
	        reader = new InputStreamReader(is);
	        bufferedReader = new BufferedReader(reader);
	        String line = null;
	        
	        while ((line = bufferedReader.readLine()) != null) {
	        	Testcase=String2List(line);
	                
	            h.Sort(Testcase);
	                
	            for(int i=0;i<Testcase.size();i++) {
	            	bw.write(Testcase.get(i)+" ");
	            }
	                
	                bw.newLine();
	            }

	        	Heapsort.clearCoverage();
	            
	        	bw.flush();        
    			bw.close();        
    			fw.close();
    			 
	            bufferedReader.close();
	            reader.close();
	            is.close();
    			
	            
	            
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } 	
		return TOfile;

	}
	
	public static List<Integer> String2List(String line){
		List<Integer> list=new ArrayList<Integer>();
		String[] str=line.split(" ");
		
		int num;
		
		for(String s:str) {
			num=Integer.parseInt(s);
			list.add(num);
		}
		
		return list;	
	}
	
}
