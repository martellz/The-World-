package Heapsort;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class TestRunner {
	/*
	 * this class is used to compare the differences between TRfile and TOfile, 
	 * then we get the index of failed cases and passed cases
	 * 
	 * It is also used to run passed cases and failed cases respectively,
	 * then we get the coverage information of each line in Heapsort
	 * 
	 */
	public static void runPassedcase(File TCfile,List<Integer> Passedindex) {
		
		//record the line number of TC when it is read
		int lineno=0;
		
		//record the index of Passedindex list
		int index=0;
	
		Heapsort h=new Heapsort();
		
		//as the input of h.Sort(List)
		List<Integer> Testcase=new ArrayList<Integer>();
	
		try {			
			//read
			InputStream is = null;
	        Reader reader = null;
	        BufferedReader bufferedReader = null;
	      
	        is = new FileInputStream(TCfile);
	        reader = new InputStreamReader(is);
	        bufferedReader = new BufferedReader(reader);
	        String line = null;
	        
	        while ((line = bufferedReader.readLine()) != null) {
	        	lineno=lineno+1;
	        	
	        	//if lineno is equal to Passedindex, then run Heapsort
	        	if(index<Passedindex.size() &&
	        			lineno==Passedindex.get(index)) {
	        			Testcase=Testresult.String2List(line);			           
	        			h.Sort(Testcase);     
	        			index=index+1;
		        	}
	        	}
	        
	        bufferedReader.close();
	        reader.close();
	        is.close();
    					            
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } 	
}


	public static void runFailedcase(File TCfile,List<Integer> Failedindex) {
		//record the line number of TC when it is read
		int lineno=0;
		
		//record the index of Failedindex list
		int index=0;
	
		Heapsort h=new Heapsort();
		
		//as the input of h.Sort(List)
		List<Integer> Testcase=new ArrayList<Integer>();
	
		try {			
			//read
			InputStream is = null;
	        Reader reader = null;
	        BufferedReader bufferedReader = null;
	      
	        is = new FileInputStream(TCfile);
	        reader = new InputStreamReader(is);
	        bufferedReader = new BufferedReader(reader);
	        String line = null;
	        
	        while ((line = bufferedReader.readLine()) != null) {
	        	lineno=lineno+1;
	        	
	        	//if lineno is equal to Failedindex, then run Heapsort
	        	if(index<Failedindex.size() &&
	        			lineno==Failedindex.get(index)) {
	        			Testcase=Testresult.String2List(line);
			           
	        			h.Sort(Testcase); 
			            
	        			index=index+1;
		        	}
	        	}
	        
	        bufferedReader.close();
	        reader.close();
	        is.close();
						            
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } 	     
	       
	}
	
	
	
	public static List<Integer> getFailedindex(File TRfile,File TOfile) {
		//record the index of test case 
		int index=0;
				
		//store all the index of test case that result is passed
		List<Integer> Failedindex=new ArrayList<Integer>();
				
				
		try {
			if(!TOfile.exists() || !TRfile.exists()){    
			System.out.println("File is not exist!"); 
			return null;
			}  
					
					//read
					InputStream r_is = null;
			        Reader r_reader = null;
			        BufferedReader r_bufferedReader = null;
			        
			        InputStream o_is = null;
			        Reader o_reader = null;
			        BufferedReader o_bufferedReader = null;
			      
			        r_is= new FileInputStream(TRfile);
			        r_reader = new InputStreamReader(r_is);
			        r_bufferedReader = new BufferedReader(r_reader);
			        String r_line = null;
			        
			        o_is = new FileInputStream(TOfile);
			        o_reader = new InputStreamReader(o_is);
			        o_bufferedReader = new BufferedReader(o_reader);
			        String o_line = null;
			        
			        
			        while ((r_line = r_bufferedReader.readLine()) != null &&
			        		(o_line = o_bufferedReader.readLine()) != null) {
			        	index=index+1;
			        	
			        	if(!r_line.equals(o_line)){
			        		Failedindex.add(index);
			        	}
			         }
			 
			         r_bufferedReader.close();
			         r_reader.close();
			         r_is.close();
			         
			         o_bufferedReader.close();
			         o_reader.close();
			         o_is.close();
		    			
			        } catch (FileNotFoundException e) {
			            e.printStackTrace();
			        } catch (IOException e) {
			            e.printStackTrace();
			        } 
				
				return Failedindex;		
		
		
	}


	public static List<Integer> getPassedindex(File TRfile,File TOfile) {
		
		//record the index of test case 
		int index=0;
		
		//store all the index of test case that result is passed
		List<Integer> Passedindex=new ArrayList<Integer>();
		
		
		try {
			
			
			if(!TOfile.exists() || !TRfile.exists()){    
			System.out.println("File is not exist!"); 
			return null;
			}  
			
			//read
			InputStream r_is = null;
	        Reader r_reader = null;
	        BufferedReader r_bufferedReader = null;
	        
	        InputStream o_is = null;
	        Reader o_reader = null;
	        BufferedReader o_bufferedReader = null;
	      
	        r_is= new FileInputStream(TRfile);
	        r_reader = new InputStreamReader(r_is);
	        r_bufferedReader = new BufferedReader(r_reader);
	        String r_line = null;
	        
	        o_is = new FileInputStream(TOfile);
	        o_reader = new InputStreamReader(o_is);
	        o_bufferedReader = new BufferedReader(o_reader);
	        String o_line = null;
	        
	        
	        while ((r_line = r_bufferedReader.readLine()) != null &&
	        		(o_line = o_bufferedReader.readLine()) != null) {
	        	index=index+1;
	        	
	        	if(r_line.equals(o_line)){
	        		Passedindex.add(index);
	        	}
	         }
	 
	         r_bufferedReader.close();
	         r_reader.close();
	         r_is.close();
	         
	         o_bufferedReader.close();
	         o_reader.close();
	         o_is.close();
				
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } 
		
		return Passedindex;
	}
	
	}
