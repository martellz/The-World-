package Heapsort;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;


public class Testcase{
	
	/*
	 * ��Random ���ɵ����������һ��test case ������List�
	 * ��List���������д���.txt���ļ���
	 * caseNo�涨һ���м���test case��caseSize�涨һ��test case����м�������
	 * 
	 */
	
	public File getTestcase(int caseNo, int caseSize){
		
		//use system time as the name of test case file
		String fileName =new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())+".txt";
		String path = "c:\\Users\\qhy\\Desktop\\Tarantula\\Heapsort\\Testcase"+fileName;        
		
		//store a test case in a List
		List<Integer> Testcase=new ArrayList<Integer>();
				
		//generate a random number
		Random r=new Random(1);
							
		//the number of int type data in a test case
		int listSize;
		
		//define the max value of cases
		int Maxvalue=500;
		
		//insert value into A, 
		int randnum;
		
		File file=null; 
		
		try {
			
			//creat a file to store all test cases
			file=new File(path);
			
			if(!file.exists()){    
				file.createNewFile();                 
				}  
			
	        // write        
			FileWriter fw = new FileWriter(file, true);        
			BufferedWriter bw = new BufferedWriter(fw);  
			
			for(int i=0;i<caseNo;i++) {	
				
				listSize=r.nextInt(caseSize)+1;
				
				for(int j=0;j<listSize;j++) {
					//the scope of randnum is from 0 to Maxvalue
					randnum=r.nextInt(Maxvalue);
					Testcase.add(randnum);
					}
							
				for(int k=0;k<Testcase.size();k++) {
					bw.write(Testcase.get(k)+" ");
				}
				bw.newLine();
				Testcase.removeAll(Testcase);
			}
			        
			bw.flush();        
			bw.close();        
			fw.close();
			
			}catch (IOException e) {
				e.printStackTrace();
			}
		
		return file;
	}

}
