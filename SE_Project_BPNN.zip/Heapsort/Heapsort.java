package Heapsort;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Heapsort {
	private int heapSize=0;
	
	private static Map<Integer, Integer> coverage = new HashMap<Integer,Integer>();
	private static Map<Integer, Integer> execute=new HashMap<Integer,Integer>();
	
	private int Left(int i) {
		execute.put(16, (Integer)execute.get(16)+1);
		return 2*i+1;
	}
	
	private int Right(int i) {
		execute.put(21, (Integer)execute.get(21)+1);
		return 2*i+2;
		
	}
	
	private int Parent(int i) {
		execute.put(27, (Integer)execute.get(27)+1);
		return (i+1)/2-1;
		
	}
	
	private void Max_Heapify(List<Integer> A,int i) {
		
		int largest;
		int temp;
		execute.put(36, (Integer)execute.get(36)+1);
		int l=Left(i);
		execute.put(38, (Integer)execute.get(38)+1);
		int r=Right(i);
		
		execute.put(41, (Integer)execute.get(41)+1);
		if(l<heapSize && A.get(l).compareTo(A.get(i))>0) {
			execute.put(43, (Integer)execute.get(43)+1);
			largest=l;
			
		}
		else {
			execute.put(48, (Integer)execute.get(48)+1);
			largest=i;
		}
		
		execute.put(53, (Integer)execute.get(53)+1);
		if(r<heapSize && A.get(r).compareTo(A.get(largest))>0) {
			execute.put(55, (Integer)execute.get(55)+1);
			largest=r;
			
		}
		
		execute.put(60, (Integer)execute.get(60)+1);
		if(largest!=i) {
			execute.put(62, (Integer)execute.get(62)+1);
			temp=A.get(i);
			
			execute.put(65, (Integer)execute.get(65)+1);
			A.set(i, A.get(largest));
			
			execute.put(68, (Integer)execute.get(68)+1);
			A.set(largest, temp);
			
			execute.put(71, (Integer)execute.get(71)+1);
			Max_Heapify(A,largest);
		}
	}
	
	private void Build_MaxHeap(List<Integer> A) {
		
		execute.put(78, (Integer)execute.get(78)+1);		
		if(A==null){
			return;
		}
		
		execute.put(83, (Integer)execute.get(83)+1);
		heapSize=A.size();
		
		
		for(int i=Parent(A.size()-1);i>=0;i--) {
			execute.put(86, (Integer)execute.get(86)+1);
			Max_Heapify(A,i);
			execute.put(88, (Integer)execute.get(88)+1);
		}
	}
	
	public void Sort(List<Integer>A) {
		int temp;
		
		execute.put(97, (Integer)execute.get(97)+1);
		if(A==null) {
			execute.put(98, (Integer)execute.get(98)+1);return;
		}
		
		execute.put(102, (Integer)execute.get(102)+1);
		Build_MaxHeap(A);
		
		
		for(int i=A.size()-1;i>0;i--) {
			execute.put(105, (Integer)execute.get(105)+1);
			
			execute.put(109, (Integer)execute.get(109)+1);
			temp=A.get(0);
			
			execute.put(112, (Integer)execute.get(112)+1);
			A.set(0, A.get(i));
			
			execute.put(115, (Integer)execute.get(115)+1);
			A.set(i, temp);
			
			execute.put(118, (Integer)execute.get(118)+1);
			heapSize=heapSize-1;
			
			execute.put(121, (Integer)execute.get(121)+1);
			Max_Heapify(A,0);
		}	
		Execute2Coverage();
	}
	
	public static void clearCoverage() {
		coverage.clear();
	}
	
	public static Map<Integer, Integer> getCoverage() {
		return coverage;
	}
	
	public static void Execute2Coverage() {
		/*
		 * some lines could be executed many times during running a test case
		 * but they are just covered one time during running a test case
		 * so we should convert executed times to covered times
		 */
	
		int key;
		 Iterator<Map.Entry<Integer, Integer>> it = execute.entrySet().iterator();
	     while (it.hasNext()) {
	            Map.Entry<Integer, Integer> entry = it.next();
	            key=entry.getKey();
	            if(entry.getValue()>0) {
	            	coverage.put(key,(Integer)coverage.get(key)+1);
	            }else {
	            	coverage.put(key,0);
	            }
	        }
	}
	
	
	Heapsort(){
		coverage.put(9, 0);
		coverage.put(16, 0);
		coverage.put(21, 0);
		coverage.put(27, 0);
		coverage.put(36, 0);
		coverage.put(38, 0);
		coverage.put(41, 0);
		coverage.put(43, 0);
		coverage.put(48, 0);
		coverage.put(53, 0);
		coverage.put(55, 0);
		coverage.put(60, 0);
		coverage.put(62, 0);
		coverage.put(65, 0);
		coverage.put(68, 0);
		coverage.put(71, 0);
		coverage.put(73, 0);
		coverage.put(78, 0);
		coverage.put(79, 0);
		coverage.put(83, 0);
		coverage.put(86, 0);
		coverage.put(88, 0);
		coverage.put(91, 0);
		coverage.put(97, 0);
		coverage.put(98, 0);
		coverage.put(102, 0);
		coverage.put(105, 0);
		coverage.put(109, 0);
		coverage.put(112, 0);
		coverage.put(115, 0);
		coverage.put(118, 0);
		coverage.put(121, 0);
		
		execute.put(9, 0);
		execute.put(16, 0);
		execute.put(21, 0);
		execute.put(27, 0);
		execute.put(36, 0);
		execute.put(38, 0);
		execute.put(41, 0);
		execute.put(43, 0);
		execute.put(48, 0);
		execute.put(53, 0);
		execute.put(55, 0);
		execute.put(60, 0);
		execute.put(62, 0);
		execute.put(65, 0);
		execute.put(68, 0);
		execute.put(71, 0);
		execute.put(73, 0);
		execute.put(78, 0);
		execute.put(79, 0);
		execute.put(83, 0);
		execute.put(86, 0);
		execute.put(88, 0);
		execute.put(91, 0);
		execute.put(97, 0);
		execute.put(98, 0);
		execute.put(102, 0);
		execute.put(105, 0);
		execute.put(109, 0);
		execute.put(112, 0);
		execute.put(115, 0);
		execute.put(118, 0);
		execute.put(121, 0);
	}
}
