package Heapsort;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Coverage {
	
	//use List to store the index of failed test cases and passed test cases
	private static List<Integer> Failedindex;
	private static List<Integer> Passedindex;
	
	//use Map to store the coverage information of each line in Heapsort 
	public static Map<Integer,Integer> passedCoverage=new HashMap<Integer,Integer>();
	public static Map<Integer,Integer> failedCoverage=new HashMap<Integer,Integer>();
	
	//use to get the information and data of test case file, test oracle file and test  result file
	private static File TRfile;
	private static File TCfile;
	private static File TOfile;
	
	//compute the total number of passed cases and failed cases 
	public static int totalpassed;
	public static int totalfailed;
	
	public static void getTcToPath(int caseno,int casesize) {
		 //use the static method of Testcase and Testresult class to create the test case and test oracle
		Testcase TC=new Testcase();
		
		TCfile=TC.getTestcase(caseno, casesize);
		
		TOfile=Testresult.getTestoracle(TCfile);
		
		
		//print the absolute path of these files in console
		System.out.println(TCfile.getAbsolutePath());
		System.out.println(TOfile.getAbsolutePath());
	}
	
	private static void setTCfile(String TCpath){
		TCfile=new File(TCpath);
	}
	
	private static void setTOfile(String TOpath){
		TOfile=new File(TOpath);
	}
	
	
	public static void get(String TCpath,String TOpath) {
		setTCfile(TCpath);
		setTOfile(TOpath);
		
		//After get test oracle,get the test result
		TRfile=Testresult.getTestresult(TCfile);
		
		//Compare the differences between TRfile and TOfile, then get the failed index and passed index
		Failedindex=TestRunner.getFailedindex(TRfile,TOfile);
		Passedindex=TestRunner.getPassedindex(TRfile,TOfile);   
		
		//print
		System.out.println("The indexs of failed test cases :");
		System.out.println(Failedindex);
		System.out.println();
		System.out.println("The indexs of passed test cases :");
		System.out.println(Passedindex);
		System.out.println();
		
		//the size of failedindex is the total number of failed cases 
		setTotalpassed(Failedindex.size());
		
		
		//the size of passedindex is the total number of passed cases 
		setTotalfailed(Passedindex.size());
		
		//run the failed case, the get the coverage info of each line, stored in failedCoverage Map
		setFailedcoverage(TCfile);
		
		//run the passed case, the get the coverage info of each line, stored in passedCoverage Map
		setPassedcoverage(TCfile);
		
		//print
		System.out.println("The coverage counts of each line when run failed test cases :");
		System.out.println(failedCoverage);
		System.out.println();
		System.out.println("The coverage counts of each line when run passed test cases :");
		System.out.println(passedCoverage);
		System.out.println();
	}
	
	private static void setTotalpassed(int p) {
		totalpassed=p;
	}
	
	private static void setTotalfailed(int f) {
		totalfailed=f;
	}
	
	private static void setFailedcoverage(File TCfile){
		
		
		if(Failedindex==null || !TCfile.exists() ||
				!TRfile.exists()) {
			System.out.println("Get failed coverage information fail!");
			return;
		}
		
		TestRunner.runFailedcase(TCfile, Failedindex);
		failedCoverage.putAll(Heapsort.getCoverage());
		return;
	}
	
	private static void setPassedcoverage(File TCfile) {
		
		if(Passedindex==null || !TCfile.exists() ||
				!TRfile.exists()) {
			System.out.println("Get passed coverage information fail!");
			return;
		}
		
		TestRunner.runPassedcase(TCfile, Passedindex);
		passedCoverage.putAll(Heapsort.getCoverage());
		return;
	}
}
