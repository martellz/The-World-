package Heapsort;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Tarantula {
	private static  Map<Integer,Float> suspic=new HashMap<Integer,Float>();
	
	private static Map<Integer,Integer> rank=new HashMap<Integer,Integer>();
	
	private static List<Integer> lineno=new ArrayList<Integer>();
	
	public static void get(Map<Integer,Integer> FailedCoverage,Map<Integer,Integer> PassedCoverage,
							int totalpassed,int totalfailed){
		setSuspic(FailedCoverage,PassedCoverage,totalpassed,totalfailed);
	     
		System.out.println("The suspuicious score of each line: ");
	    System.out.println(suspic);
	    System.out.println();
 
	    setRank();
	   
	    System.out.println("The rank of each line: ");
	    Printrank();
	    
	}
	
	private static void Printrank() {
		for(Integer i:lineno) {
			System.out.println("line"+i+"	"+rank.get(i));
		}
	}
	
	private static void setSuspic(Map<Integer,Integer> FailedCoverage,Map<Integer,Integer> PassedCoverage,
			int totalfailed,int totalpassed) {
		float passedrate;
		float failedrate;
		
		float suspicscore;
		
		
		
		 Iterator<Map.Entry<Integer, Integer>> it = PassedCoverage.entrySet().iterator();
	     while (it.hasNext()) {
	           Map.Entry<Integer, Integer> ss = it.next();
	            
	           if(totalfailed==0) {
	        	   suspic.put(ss.getKey(), (float) 0);
	        	   continue;
	   			}
	           
	           if(totalpassed==0){
	        	   suspic.put(ss.getKey(), (float) 1);
	        	   continue;
	           }
	           
	           passedrate=(float)ss.getValue()/totalpassed; 
	            
	           failedrate=(float)FailedCoverage.get(ss.getKey())/totalfailed;
	          
	           if(passedrate==0 && failedrate==0) {
	        	   suspic.put(ss.getKey(), (float) 0);
	           }else {
	        	   suspicscore=(float)failedrate/(passedrate+failedrate);
		           suspic.put(ss.getKey(), suspicscore);
	           }
	     }
	}
	
	
	private static void setRank() {
		setLineno();
		int r=1;
		
		
		for(int i=0;i<lineno.size();i++) {
			if(i==0) {
				rank.put(lineno.get(i), r);
				continue;
			}
			
			if(suspic.get(lineno.get(i)).equals(suspic.get(lineno.get(i-1)))) {
				rank.put(lineno.get(i), r);
			}else {
				r=r+i;
				rank.put(lineno.get(i), r);
			}
		}
	 }
	
	
	private static void setLineno() {
		for(Integer key:suspic.keySet()) {
	           lineno.add(key);
	    }
		
		Quicksort(lineno,0,lineno.size()-1);

	}
	
	//use quick sort to sort the value of suspic
	private static void Quicksort(List<Integer>lineno,int p,int r) {
		int q;
		if(p<r) {
			q=Partition(lineno,p,r);
			Quicksort(lineno,p,q-1);
			Quicksort(lineno,q+1,r);
		}
	}
	
	private static int Partition(List<Integer>lineno,int p,int r) {
		float x=suspic.get(lineno.get(r));
		int i=p-1;
		int temp;
		
		for(int j=p;j<r;j++) {
			if(suspic.get(lineno.get(j))<=x) {
				i=i+1;
				
				//exchange lineno(j)with lineno(i)
				temp=lineno.get(j);
				lineno.set(j, lineno.get(i));
				lineno.set(i, temp);
			}
		}
		
		temp=lineno.get(i+1);
		lineno.set(i+1, lineno.get(r));
		lineno.set(r, temp);
		
		return i+1;
	}
		
	
	
}
