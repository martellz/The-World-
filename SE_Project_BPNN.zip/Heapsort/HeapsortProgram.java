package Heapsort;

public class HeapsortProgram {
	
	 public static void main(String[] args) {
		 
		/*
		 * Step1��set the number of test cases(caseno) and the max size of each test case(casesize);
		 * Step2:delete the annotation of line 21, run the program
		 * Step3:copy the path of test case file in console to String TCpath
		 * Step4:copy the path of test oracle file in console to String TOpath
		 * Step5:add errors to test program(Heasort.java)
		 * Step6:delete the annotation of line 228 and 30,add annotation to line 21 
		 * Step7:run the program
		 * 
		 */
		 
		int caseno=100;
		int casesize=50;
		
		//Coverage.getTcToPath(caseno, casesize);
		
		//Before execute below lines, You must add errors to Heapsort
		
		String TCpath="c:\\Users\\qhy\\Desktop\\Tarantula\\Heapsort\\Testcase20191111230214.txt";
		String TOpath="c:\\Users\\qhy\\Desktop\\Tarantula\\Heapsort\\Testoracle-Testcase20191111230214.txt";
		
		/*	Coverage.get(TCpath,TOpath);
		
		Tarantula.get(Coverage.failedCoverage,Coverage.passedCoverage,Coverage.totalfailed,Coverage.totalpassed);
		*/
	}
	
}

